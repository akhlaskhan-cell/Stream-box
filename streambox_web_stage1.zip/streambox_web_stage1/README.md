# StreamBox Web — Stage 1

Responsive movie/TV discovery website using Next.js, TypeScript and Tailwind CSS.

## Included
- Responsive dark homepage
- TMDB trending, popular movies and top-rated TV
- Multi-search
- Movie/TV details pages
- Server-side TMDB proxy (token is not sent to the browser)
- Netplay API integration plan and authorization notes

## Run locally
Requires Node.js 20.9+.
1. Extract this ZIP.
2. Copy `.env.example` to `.env.local`.
3. Add your own TMDB Read Access Token to `TMDB_READ_ACCESS_TOKEN`.
4. Run `npm install`.
5. Run `npm run dev`.
6. Open http://localhost:3000.

## Deploy from a phone
Upload the extracted files to a GitHub repository using your mobile browser, import the repository into Vercel, add `TMDB_READ_ACCESS_TOKEN` under Project Settings → Environment Variables, and deploy.

TMDB credentials: https://www.themoviedb.org/settings/api

Never commit `.env.local`. Never expose provider credentials or database service-role keys in browser code.

## Stage 1 limitations
Catalogue uses live TMDB data once configured. Playback, authentication, persistent watchlists, admin dashboard and authorized provider adapters are later stages.
