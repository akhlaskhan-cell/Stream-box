import Image from "next/image";
import Link from "next/link";
import {imageUrl,TmdbTitle} from "@/lib/tmdb";
export default function TitleCard({item}:{item:TmdbTitle}) {
 const title=item.title||item.name||"Untitled"; const poster=imageUrl(item.poster_path); const type=item.media_type||(item.first_air_date?"tv":"movie");
 return <Link href={`/title/${type}/${item.id}`} className="group block min-w-0">
  <div className="relative aspect-[2/3] overflow-hidden rounded-xl border border-white/10 bg-gradient-to-br from-indigo-900 to-violet-950">
   {poster&&<Image src={poster} alt={`${title} poster`} fill sizes="(max-width:640px) 42vw,180px" className="object-cover transition group-hover:scale-105"/>}
   <span className="absolute right-2 top-2 rounded bg-black/75 px-2 py-1 text-xs">★ {item.vote_average?.toFixed(1)??"—"}</span>
  </div><h3 className="mt-2 truncate text-sm font-semibold">{title}</h3>
  <p className="text-xs text-slate-400">{(item.release_date||item.first_air_date||"").slice(0,4)||"Year unavailable"}</p>
 </Link>;
}