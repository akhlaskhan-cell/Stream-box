"use client";
import {useEffect,useState} from "react";
import TitleCard from "@/components/TitleCard";
import type {TmdbTitle} from "@/lib/tmdb";
type Data={trending:TmdbTitle[];popular:TmdbTitle[];series:TmdbTitle[]};
function Row({title,items}:{title:string;items:TmdbTitle[]}) { return <section className="mt-10"><h2 className="mb-4 text-xl font-bold">{title}</h2><div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-6">{items.slice(0,12).map(x=><TitleCard key={`${x.media_type||"movie"}-${x.id}`} item={x}/>)}</div></section>; }
export default function Home() {
 const [data,setData]=useState<Data|null>(null); const [error,setError]=useState("");
 useEffect(()=>{fetch("/api/home").then(async r=>{const b=await r.json();if(!r.ok)throw new Error(b.error||"Could not load catalogue");setData(b);}).catch(e=>setError(e.message));},[]);
 return <>
 <header className="sticky top-0 z-20 border-b border-white/10 glass"><div className="container flex h-16 items-center justify-between"><a href="/" className="font-black tracking-[.2em] text-violet-300">STREAMBOX</a><nav className="hidden gap-6 text-sm text-slate-300 sm:flex"><a href="#trending">Trending</a><a href="#movies">Movies</a><a href="#series">Series</a></nav><a href="/search" className="rounded-full border border-white/20 px-4 py-2 text-sm">Search</a></div></header>
 <main className="container pb-16 pt-8"><section className="rounded-3xl border border-white/10 bg-gradient-to-br from-indigo-950 via-violet-950 to-slate-950 p-8 sm:p-12"><p className="text-xs font-bold tracking-[.25em] text-violet-200">YOUR ENTERTAINMENT DESTINATION</p><h1 className="mt-4 max-w-2xl text-4xl font-black leading-tight sm:text-6xl">Discover your next favourite.</h1><p className="mt-4 max-w-xl text-sm leading-6 text-slate-300">Explore movies and series with a fast, clean catalogue. Licensed playback will be connected through an authorized provider.</p><a href="/search" className="mt-7 inline-block rounded-full bg-violet-500 px-6 py-3 text-sm font-bold">Explore titles</a></section>
 {error&&<p className="mt-8 rounded-xl border border-amber-500/30 bg-amber-950/30 p-4 text-sm text-amber-200">{error.includes("not configured")?"TMDB is not connected. Add your token to .env.local and restart the site.":error}</p>}
 {!data&&!error&&<p className="mt-10 text-sm text-slate-400">Loading catalogue…</p>}
 {data&&<><div id="trending"><Row title="Trending this week" items={data.trending}/></div><div id="movies"><Row title="Popular movies" items={data.popular}/></div><div id="series"><Row title="Top-rated series" items={data.series.map(x=>({...x,media_type:"tv"}))}/></div></>}
 </main><footer className="border-t border-white/10 py-8 text-center text-xs text-slate-500">Metadata and images powered by TMDB. Not endorsed or certified by TMDB. Streaming depends on authorized providers.</footer></>;
}