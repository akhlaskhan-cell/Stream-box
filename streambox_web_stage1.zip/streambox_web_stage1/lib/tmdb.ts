const BASE = "https://api.themoviedb.org/3";
export type TmdbTitle = { id:number; title?:string; name?:string; overview?:string; poster_path:string|null; backdrop_path:string|null; vote_average?:number; release_date?:string; first_air_date?:string; media_type?:string };
export function imageUrl(path:string|null,size="w500") { return path ? `https://image.tmdb.org/t/p/${size}${path}` : null; }
export async function tmdb(path:string,params:Record<string,string>={}) {
  const token=process.env.TMDB_READ_ACCESS_TOKEN;
  if(!token) throw new Error("TMDB_READ_ACCESS_TOKEN is not configured.");
  const url=new URL(`${BASE}${path}`);
  Object.entries(params).forEach(([k,v])=>url.searchParams.set(k,v));
  const res=await fetch(url,{headers:{Authorization:`Bearer ${token}`,accept:"application/json"},next:{revalidate:1800}});
  if(!res.ok) throw new Error(`TMDB request failed (${res.status}).`);
  return res.json();
}