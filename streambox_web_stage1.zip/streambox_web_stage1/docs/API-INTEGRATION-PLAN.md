# API integration plan

## Integrated in Stage 1
- TMDB v3 through server-side Next.js route handlers.
- Trending, popular movies and top-rated TV.
- Multi-search.
- Movie/TV metadata details.
- TMDB image CDN.

## References observed in the Netplay APK (not integrated)
- api.themoviedb.org
- h5-api.aoneroom.com
- api.inmoviebox.com
- api6.aoneroom.com and other numbered Aoneroom hosts
- Netplay Cloudflare Worker
- Netplay Firebase Realtime Database
- Cloudflare R2 catalogue/config resources
- Vega provider manifest and provider sandbox

Static APK references do not establish public access, permission, current availability, HTTP methods, authentication or response schemas.

## Rules for later integrations
1. TMDB: use your own credentials and comply with TMDB terms and attribution.
2. Aoneroom/InMovieBox: require provider authorization and official documentation.
3. Netplay Worker/Firebase/R2: do not reuse another application's private backend, credentials or data without owner permission.
4. Vega: inspect repository and individual provider licences, source domains and content rights. Do not execute untrusted downloaded JavaScript in production.
5. Playback: use only content you own or are licensed to distribute. Do not bypass DRM, access controls or authentication.

Build provider adapters server-side after receiving approved documentation. Keep secrets in server environment variables; browser code should call your own API routes.
