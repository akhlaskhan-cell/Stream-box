import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title:"StreamBox — Movies & Series", description:"A modern movie and TV discovery website." };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }