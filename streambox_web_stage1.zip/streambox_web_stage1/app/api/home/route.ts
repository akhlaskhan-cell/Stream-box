import {NextResponse} from "next/server";
import {tmdb} from "@/lib/tmdb";
export async function GET() {
 try {
  const [trending,popular,series]=await Promise.all([tmdb("/trending/all/week"),tmdb("/movie/popular"),tmdb("/tv/top_rated")]);
  return NextResponse.json({trending:trending.results??[],popular:popular.results??[],series:series.results??[]});
 } catch(e) { return NextResponse.json({error:e instanceof Error?e.message:"Server error"},{status:500}); }
}