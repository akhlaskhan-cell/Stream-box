import {NextRequest,NextResponse} from "next/server";
import {tmdb} from "@/lib/tmdb";
export async function GET(req:NextRequest) {
 const q=req.nextUrl.searchParams.get("q")?.trim()??"";
 if(!q) return NextResponse.json({results:[]});
 if(q.length>100) return NextResponse.json({error:"Query too long."},{status:400});
 try { const data=await tmdb("/search/multi",{query:q,include_adult:"false"}); return NextResponse.json({results:data.results??[]}); }
 catch(e) { return NextResponse.json({error:e instanceof Error?e.message:"Search failed."},{status:500}); }
}