import {NextRequest,NextResponse} from "next/server";
import {tmdb} from "@/lib/tmdb";
export async function GET(_req:NextRequest,ctx:{params:Promise<{type:string;id:string}>}) {
 const {type,id}=await ctx.params;
 if(!["movie","tv"].includes(type)||!/^[0-9]+$/.test(id)) return NextResponse.json({error:"Invalid title."},{status:400});
 try { const data=await tmdb(`/${type}/${id}`,{append_to_response:"videos,credits"}); return NextResponse.json(data); }
 catch(e) { return NextResponse.json({error:e instanceof Error?e.message:"Request failed."},{status:500}); }
}