"use client";
import {useState} from "react";
import TitleCard from "@/components/TitleCard";
import type {TmdbTitle} from "@/lib/tmdb";
export default function SearchPage(){
 const [q,setQ]=useState("");const [items,setItems]=useState<TmdbTitle[]>([]);const [busy,setBusy]=useState(false);const [error,setError]=useState("");
 async function submit(e:React.FormEvent){e.preventDefault();if(!q.trim())return;setBusy(true);setError("");try{const r=await fetch(`/api/search?q=${encodeURIComponent(q.trim())}`);const b=await r.json();if(!r.ok)throw new Error(b.error||"Search failed");setItems(b.results||[]);}catch(e){setError(e instanceof Error?e.message:"Search failed");}finally{setBusy(false);}}
 return <main className="container min-h-screen py-8"><a href="/" className="text-sm text-violet-300">← Home</a><h1 className="mt-8 text-3xl font-black">Search titles</h1><form onSubmit={submit} className="mt-6 flex gap-2"><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Movie, series or person…" className="min-w-0 flex-1 rounded-xl border border-white/15 bg-slate-900 px-4 py-3 outline-none focus:border-violet-400"/><button disabled={busy} className="rounded-xl bg-violet-500 px-5 font-bold disabled:opacity-50">{busy?"…":"Search"}</button></form>{error&&<p className="mt-5 text-amber-300">{error}</p>}<div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-6">{items.filter(x=>x.poster_path).map(x=><TitleCard key={`${x.media_type||"movie"}-${x.id}`} item={x}/>)}</div></main>;
}